# Quiz de Segurança Digital (versão 100% Java)

Aplicativo desktop em **Java puro (Swing/Java2D)**, sem nenhuma biblioteca externa, com as mesmas funções do quiz para web.

## Funções

- 20 perguntas em 5 etapas de 4 perguntas, cada uma com 4 alternativas e uma única resposta correta (nível básico a intermediário).
- Barra de progresso, botão Voltar, e o botão Próxima só libera depois de escolher uma alternativa.
- Resultado final com:
  - pontuação e avaliação;
  - **gráfico de pizza geral** (acertos e erros, com quantidade e porcentagem);
  - **uma pizza por etapa**, com acertos, erros e porcentagens;
  - detalhamento de **cada pergunta errada**: sua resposta, a resposta certa e a explicação.
- Campo de nome opcional, **ranking** (top 10), **histórico** das últimas tentativas e **perguntas mais erradas** de todas as tentativas, guardados no arquivo `~/.quiz-seguranca-digital/historico.csv`.
- Visual em azul e roxo e o **dragão voador**: corpo articulado, asas que batem, patas, cauda com barbatana, olhos que seguem o mouse e sopro de faíscas a cada nova pergunta. Dá para desligá-lo na caixa "Dragão animado".
- Layout que se adapta à largura da janela (de tela grande a estreita).

## Como jogar

Requisito: Java 17 ou superior.

```bash
java -jar quiz-seguranca-digital.jar
```

Em muitos sistemas basta dar dois cliques no arquivo `.jar`.

## Como compilar

```bash
./build.sh          # Linux/macOS
build.bat           # Windows
```

Ou manualmente:

```bash
javac -encoding UTF-8 --release 17 -d out src/com/kauafz/quiz/*.java
java -cp out com.kauafz.quiz.Main
```

## Testes

Os testes de autoverificação não usam bibliotecas (89 verificações: banco de perguntas, correção, percentuais, ranking, histórico e estatísticas):

```bash
java -cp quiz-seguranca-digital.jar com.kauafz.quiz.SelfTest
```

## Estrutura

```
src/com/kauafz/quiz
├── Main.java          janela principal
├── QuizApp.java       telas (abertura, perguntas, resultado) e animação
├── Dragon.java        dragão voador desenhado com Java2D
├── Ui.java            componentes visuais: layout, cartões, opções, botões, gráficos de pizza
├── QuizEngine.java    correção, percentuais e detalhamento dos erros
├── HistoryStore.java  histórico, ranking e estatísticas em arquivo
├── QuestionBank.java  as 20 perguntas, com explicações
├── Question.java      modelo de pergunta
├── Theme.java         cores e fontes
├── SelfTest.java      testes
└── Shots.java         gera capturas de tela das telas (uso em desenvolvimento)
```

Para mudar as perguntas, edite `QuestionBank.java`: cada `Question` recebe a etapa, o enunciado, as 4 alternativas, o índice da correta (0 a 3) e a explicação.

## Licença

MIT
