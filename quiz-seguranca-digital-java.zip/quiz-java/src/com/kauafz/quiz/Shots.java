package com.kauafz.quiz;

import javax.imageio.ImageIO;
import javax.swing.JScrollPane;
import java.awt.Component;
import java.awt.Container;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

/** Gera capturas de tela das telas do quiz em modo headless (usado só em desenvolvimento). */
public final class Shots {

    private Shots() {
    }

    private static void layout(Component c) {
        if (c instanceof Container ct) {
            ct.doLayout();
            for (Component child : ct.getComponents()) {
                layout(child);
            }
        }
    }

    private static void snap(QuizApp app, String file, int w, int h, boolean full) throws Exception {
        java.awt.Component root = app.component();
        root.setSize(w, h);
        layout(root);
        // altura total do conteúdo para capturas "completas"
        if (full) {
            JScrollPane sp = (JScrollPane) ((Container) root).getComponent(1);
            int ph = sp.getViewport().getView().getPreferredSize().height;
            h = Math.max(h, ph + 60);
            root.setSize(w, h);
            layout(root);
            sp.getViewport().getView().setSize(w, ph);
            layout(sp.getViewport().getView());
        }
        BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = img.createGraphics();
        root.paint(g);
        g.dispose();
        ImageIO.write(img, "png", new File(file));
        System.out.println("gerado " + file + " (" + w + "x" + h + ")");
    }

    public static void run(String dir, int width) throws Exception {
        System.setProperty("java.awt.headless", "true");
        Path tmp = Files.createTempDirectory("quiz-shots");
        HistoryStore store = new HistoryStore(tmp);
        Files.createDirectories(Path.of(dir));
        QuizApp app = new QuizApp(store);
        app.dragon().settle(14);

        snap(app, dir + "/1-intro.png", width, 760, false);

        app.showQuestion();
        app.dragon().settle(6);
        snap(app, dir + "/2-pergunta.png", width, 760, false);

        int[] answers = new int[QuestionBank.ALL.size()];
        for (int i = 0; i < answers.length; i++) {
            int c = QuestionBank.ALL.get(i).correct();
            answers[i] = i % 3 == 0 ? (c + 1) % 4 : c;
        }
        store.save("Maria", QuizEngine.grade(QuestionBank.ALL, QuestionBank.PARTS, new int[]{
                1, 2, 3, 0, 2, 1, 3, 0, 1, 3, 2, 0, 1, 2, 3, 1, 2, 3, 1, 2}));
        QuizEngine.Result r = QuizEngine.grade(QuestionBank.ALL, QuestionBank.PARTS, answers);
        store.save("Kauã", r);
        app.buildResultPage(r);
        app.dragon().settle(5);
        snap(app, dir + "/3-resultado.png", width, 900, true);
        snap(app, dir + "/4-resultado-celular.png", 420, 900, true);
        System.out.println(Arrays.toString(answers));
    }
}
