import com.kauafz.quiz.Shots;

/** Ferramenta de desenvolvimento: gera PNGs das telas sem abrir janela. */
public final class Screenshots {
    public static void main(String[] args) throws Exception {
        Shots.run(args.length > 0 ? args[0] : "shots", args.length > 1 ? Integer.parseInt(args[1]) : 980);
    }
}
