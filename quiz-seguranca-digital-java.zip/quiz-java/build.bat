@echo off
rem Compila o projeto e gera o JAR executavel (requer JDK 17 ou superior)
if exist out rmdir /s /q out
mkdir out
javac -encoding UTF-8 --release 17 -d out src\com\kauafz\quiz\*.java || exit /b 1
jar --create --file quiz-seguranca-digital.jar --main-class com.kauafz.quiz.Main -C out . || exit /b 1
echo Pronto: quiz-seguranca-digital.jar
echo Para jogar: java -jar quiz-seguranca-digital.jar
